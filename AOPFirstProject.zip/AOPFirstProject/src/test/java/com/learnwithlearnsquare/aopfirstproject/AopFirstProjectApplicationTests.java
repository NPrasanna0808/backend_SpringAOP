package com.learnwithlearnsquare.aopfirstproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AopFirstProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
