package com.learnwithlearnsquare.aopfirstproject;

import com.learnwithlearnsquare.aopfirstproject.service.MyService;
import com.learnwithlearnsquare.aopfirstproject.exception.MyCustomException;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication
@EnableAspectJAutoProxy
public class AopFirstProjectApplication implements CommandLineRunner {

    private final MyService myService;

    public AopFirstProjectApplication(MyService myService) {
        this.myService = myService;
    }

    public static void main(String[] args) {
        SpringApplication.run(AopFirstProjectApplication.class, args);
    }

    @Override
    public void run(String... args) {
        System.out.println("\n--- Calling service methods ---");
        myService.doSomething();
        myService.doSomethingWithArgs("Hello AOP", 123);

        try {
            myService.doSomethingThatThrowsException();
        } catch (MyCustomException e) {
            System.out.println("Caught expected exception in main app: " + e.getMessage());
        }

        System.out.println("--- Service method calls finished ---\n");
    }
}
